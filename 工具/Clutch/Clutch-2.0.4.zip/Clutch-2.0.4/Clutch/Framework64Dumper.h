//
//  Framework64Dumper.h
//  Clutch
//
//  Created by Anton Titkov on 02.04.15.
//
//

#import "Dumper.h"

@interface Framework64Dumper : Dumper <FrameworkBinaryDumpProtocol>

@end
