//
//  ARMDumper.h
//  Clutch
//
//  Created by Anton Titkov on 22.03.15.
//
//

#import "Dumper.h"

@interface ARMDumper : Dumper <BinaryDumpProtocol>

@end
