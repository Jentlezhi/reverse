//
//  ARM64Dumper.h
//  Clutch
//
//  Created by Anton Titkov on 22.03.15.
//
//

#import "Dumper.h"

@interface ARM64Dumper : Dumper <BinaryDumpProtocol>

@end
