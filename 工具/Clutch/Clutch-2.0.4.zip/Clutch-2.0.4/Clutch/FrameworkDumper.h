//
//  FrameworkDumper.h
//  Clutch
//
//  Created by Anton Titkov on 02.04.15.
//
//

#import "Dumper.h"

@interface FrameworkDumper : Dumper <FrameworkBinaryDumpProtocol>

@end
